#include <GL/glut.h>
#include <math.h>

GLfloat shiftX = 0;
GLfloat shiftY = 0;

GLfloat scaleX = 0;
GLfloat scaleY = 0;
//SUN
float sunX = -0.6f; // Initial x-coordinate of the sun
float sunY = 0.5f; // Initial y-coordinate of the sun
float targetY = 0.875f; // Target y-coordinate for the sun to stop
float sunRadius = 0.07f; // Radius of the sun
int numSegments = 50; // Number of segments for drawing the sun

//RIVERLINES
float xOffset = 0.0; // Initial x offset for shifting the lines

float cngPositionX = 2.0; // Initial x-position of the CNG
bool moveCNG = true;

float carPosX = -.8;
bool moveCar = true; // Flag to indicate if car should move

// Function to draw the glowing sun
void drawGlowingSun(float x, float y, float radius, int numSegments)
{
    // Draw outer glow
    glColor4f(1.0f, 1.0f, 0.0f, 0.5f); // Yellow color with 50% opacity
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // Center of the sun
    for (int i = 0; i <= numSegments; i++)
    {
        float angle = i * 2.0f * M_PI / numSegments;
        float newX = x + (radius * cos(angle));
        float newY = y + (radius * sin(angle));
        glVertex2f(newX, newY);
    }
    glEnd();

    // Draw middle glow
    glColor4f(1.0f, 1.0f, 0.0f, 0.3f); // Yellow color with 30% opacity
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // Center of the sun
    for (int i = 0; i <= numSegments; i++)
    {
        float angle = i * 2.0f * M_PI / numSegments;
        float newX = x + ((radius - 0.005f) * cos(angle)); // Slightly smaller radius
        float newY = y + ((radius - 0.005f) * sin(angle)); // Slightly smaller radius
        glVertex2f(newX, newY);
    }
    glEnd();

    // Draw inner glow
    glColor4f(1.0f, 1.0f, 0.0f, 0.2f); // Yellow color with 20% opacity
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // Center of the sun
    for (int i = 0; i <= numSegments; i++)
    {
        float angle = i * 2.0f * M_PI / numSegments;
        float newX = x + ((radius - 0.01f) * cos(angle)); // Smaller radius
        float newY = y + ((radius - 0.01f) * sin(angle)); // Smaller radius
        glVertex2f(newX, newY);
    }
    glEnd();
}


// Function to update the position of the sun
void updateSunPosition()
{
    // Move the sun towards the target y-coordinate
    if (sunY < targetY)
    {
        sunY += 0.0006f; // Adjust the speed of movement here
    }
}

void drawLines()
{
    // Draw horizontal line
    glColor3f(0.0, 0.0, 0.0); // Set color to black

    glBegin(GL_LINES);
    glVertex2f(-1.0, 0.0);
    glVertex2f(1.0, 0.0);
    glEnd();

    // Draw vertical line
    glBegin(GL_LINES);
    glVertex2f(0.0, -1.0);
    glVertex2f(0.0, 1.0);
    glEnd();
}

void drawCircle(float x, float y, float radius)
{
    int numSegments = 100;
    glBegin(GL_TRIANGLE_FAN);
    glVertex2f(x, y); // Center of the circle
    for (int i = 0; i <= numSegments; i++)
    {
        float angle = i * 2.0f * M_PI / numSegments;
        float newX = x + (radius * cos(angle));
        float newY = y + (radius * sin(angle));
        glVertex2f(newX, newY);
    }
    glEnd();
}

void bush(float x,float y)
{
    glColor3f(0.05, 0.23, 0);
    drawCircle(x,y,0.02);
    drawCircle(x+0.04,y,0.02);
    drawCircle(x+0.02,y+0.025,0.02);

    glBegin(GL_POLYGON);
    glVertex2f(x,y+0.02);
    glVertex2f(x,y-0.02);
    glVertex2f(x+0.04,y-0.02);
    glVertex2f(x+0.04,y+0.02);
    glEnd();

}
void createSky()
{
    glBegin(GL_QUADS);

    // Bottom
    glColor3f(1, 0.93, 0.12);
    glVertex2f(-1.0f, -1.0f);
    glVertex2f(1.0f, -1.0f);

    // Top
    glColor3f(0.47, 0.66, 0.99);
    glVertex2f(1.0f, 1.0f);
    glVertex2f(-1.0f, 1.0f);

    glEnd();
}

void centerdivider()
{
    glLineWidth(8);

    glColor3f(0.61, 0.46, 0); // Set color to black
    glBegin(GL_LINES);
    glVertex2f(0.0, -0.2520);
    glVertex2f(0.0, 1.0);
    glEnd();
    glLineWidth(1);

}



void river()
{
    glColor3f(0, 0.3, 0.7);
    glBegin(GL_POLYGON);
    glVertex2f(-1,-0.525f) ;
    glVertex2f(1,-0.525f);
    glVertex2f(1,-1);
    glVertex2f(-1,-1);
    glEnd();
}


void riverlines()
{

    // Draw the lines with an offset
    float xOffset1 = xOffset;
    glColor3f(0.08, 0, 0.58);
    glBegin(GL_LINES);
    for (float x = -1.95 + xOffset1; x <= 1.0 + xOffset1; x += 0.2) {
        for (float y = -0.55; y >= -1; y -= 0.125) {
            glVertex2f(x, y);
            glVertex2f(x + 0.1, y);
        }
    }
    glEnd();

    // Draw the second set of lines with an offset
    float xOffset2 = xOffset - 0.05; // Adjust the offset to create a staggered effect
    glColor3f(0.28, 0.36, 0.92);
    glBegin(GL_LINES);
    for (float x = -1.2 + xOffset2; x <= 1.0 + xOffset2; x += 0.2) {
        for (float y = -0.52; y >= -1; y -= 0.125) {
            glVertex2f(x, y);
            glVertex2f(x + 0.1, y);
        }
    }
    glEnd();
}


void tree(float x, float y, float scale,float r,float g,float b)
{
    // Trunk
    glColor3f(0.41, 0.2, 0.06);
    glBegin(GL_POLYGON);
    glVertex2f(x - 0.04 * scale, y);
    glVertex2f(x + 0.04 * scale, y);
    glVertex2f(x + 0.04 * scale, y + 0.375 * scale);
    glVertex2f(x - 0.04 * scale, y + 0.375 * scale);
    glEnd();

    // Leaf
    glColor3f(r,g,b);
    glBegin(GL_TRIANGLES);
    glVertex2f(x - 0.14 * scale, y + 0.225 * scale);
    glVertex2f(x + 0.14 * scale, y + 0.225 * scale);
    glVertex2f(x, y + 0.625 * scale);
    glEnd();
    glBegin(GL_TRIANGLES);
    glVertex2f(x - 0.14 * scale, y + 0.425 * scale);
    glVertex2f(x + 0.14 * scale, y + 0.425 * scale);
    glVertex2f(x, y + 0.7 * scale);
    glEnd();
}

void vhouse1()
{

    glColor3f(0.07, 0.07, 0.07);
    glBegin(GL_POLYGON);
    glVertex2f(-0.28f,-0.225f) ;
    glVertex2f(-0.3f,-0.2f);
    glVertex2f(-0.54f,-0.2f);
    glVertex2f(-0.56f,-0.225f);
    glEnd();


    glColor3f(0.07, 0.4, 0.29);
    glBegin(GL_POLYGON);
    glVertex2f(-0.54f,-0.2f) ;
    glVertex2f(-0.54f,0.0f);
    glVertex2f(-0.3f,-0.0f);
    glVertex2f(-0.3f,-0.2f);
    glEnd();

    //ROOF
    glColor3f(0.7, 0.58, 0.14);
    glBegin(GL_POLYGON);
    glVertex2f(-0.58f,0.0f) ;
    glVertex2f(-0.52f,0.125f);
    glVertex2f(-0.32f,0.125f);
    glVertex2f(-0.26f,-0.0f);
    glEnd();

    glColor3f(0.09, 0.09, 0.09);
    glBegin(GL_LINES);
    glVertex2f(-0.551f,0.05f);
    glVertex2f(-0.284f,0.05f);
    glEnd();
//DOORS AND WINDOWS
    glColor3f(0.06, 0.06, 0.06);
    glBegin(GL_POLYGON);
    glVertex2f(-0.4f,-0.125f) ;
    glVertex2f(-0.44f,-0.125f);
    glVertex2f(-0.44f,-0.2f);
    glVertex2f(-0.40f,-0.2f);
    glEnd();

    glColor3f(0.06, 0.06, 0.06);
    glBegin(GL_POLYGON);
    glVertex2f(-0.46f,-0.125f) ;
    glVertex2f(-0.5f,-0.125f);
    glVertex2f(-0.5f,-0.075f);
    glVertex2f(-0.46f,-0.075f);
    glEnd();

    glColor3f(0.06, 0.06, 0.06);
    glBegin(GL_POLYGON);
    glVertex2f(-0.34f,-0.125f) ;
    glVertex2f(-0.38f,-0.125f);
    glVertex2f(-0.38f,-0.075f);
    glVertex2f(-0.34f,-0.075f);
    glEnd();


}


void vhouse2()
{
    //BASE
    glColor3f(0.07, 0.07, 0.07);
    glBegin(GL_POLYGON);
    glVertex2f(-0.0f,-0.225f) ;
    glVertex2f(-0.0f,-0.2f);
    glVertex2f(-0.24f,-0.2f);
    glVertex2f(-0.24f,-0.225f);
    glEnd();

    //HOUSE
    glColor3f(0.97, 0.96, 0.47);
    glBegin(GL_POLYGON);
    glVertex2f(-0.02f,-0.2f) ;
    glVertex2f(-0.02f,0.075f);
    glVertex2f(-0.22f,0.025f);
    glVertex2f(-0.22f,-0.2f);
    glEnd();

    //ROOF
    glColor3f(0.07, 0.07, 0.07);
    glBegin(GL_POLYGON);
    glVertex2f(-0.24f,-0.0f) ;
    glVertex2f(-0.24f,0.025f);
    glVertex2f(0.0f,0.1f);
    glVertex2f(0.0f,0.075f);
    glEnd();

    //DOORS AND WINDOWS
    glColor3f(0.14, 0.14, 0.14);
    glBegin(GL_POLYGON);
    glVertex2f(-0.04f,-0.2f) ;
    glVertex2f(-0.04f,-0.125f);
    glVertex2f(-0.08f,-0.125f);
    glVertex2f(-0.08f,-0.2f);
    glEnd();

    glColor3f(0.14, 0.14, 0.14);
    glBegin(GL_POLYGON);
    glVertex2f(-0.12f,-0.125f) ;
    glVertex2f(-0.16f,-0.125f);
    glVertex2f(-0.16f,-0.075f);
    glVertex2f(-0.12f,-0.075f);
    glEnd();

}


void vhouse3()
{
    glColor3f(0.09, 0.09, 0.09);
    glBegin(GL_POLYGON);
    glVertex2f(-0.62f,-0.2f) ;
    glVertex2f(-0.62f,-0.175f);
    glVertex2f(-0.92f,-0.175f);
    glVertex2f(-0.92f,-0.2f);
    glEnd();

    glColor3f(0.89, 0.83, 0.17);
    glBegin(GL_POLYGON);
    glVertex2f(-0.64f,-0.175f) ;
    glVertex2f(-0.64f,0.25f);
    glVertex2f(-0.9f,0.25f);
    glVertex2f(-0.9f,-0.175f);
    glEnd();

    glColor3f(0.09, 0.09, 0.09);
    glBegin(GL_POLYGON);
    glVertex2f(-0.62f,0.025f) ;
    glVertex2f(-0.62f,0.05f);
    glVertex2f(-0.92f,0.05f);
    glVertex2f(-0.92f,0.025f);
    glEnd();


    glColor3f(0.09, 0.09, 0.09);
    glBegin(GL_POLYGON);
    glVertex2f(-0.62f,0.25f) ;
    glVertex2f(-0.62f,0.275f);
    glVertex2f(-0.92f,0.275f);
    glVertex2f(-0.92f,0.25f);
    glEnd();

    //DOORS ANS WINDOWS
    glColor3f(0.11, 0.11, 0.11);
    glBegin(GL_POLYGON);
    glVertex2f(-0.74f,-0.2f) ;
    glVertex2f(-0.74f,-0.075f);
    glVertex2f(-0.8f,-0.075f);
    glVertex2f(-0.8f,-0.2f);
    glEnd();

    glColor3f(0.11, 0.11, 0.11);
    glBegin(GL_POLYGON);
    glVertex2f(-0.68f,0.125f) ;
    glVertex2f(-0.68f,0.2f);
    glVertex2f(-0.74f,0.2f);
    glVertex2f(-0.74f,0.125f);
    glEnd();

    glColor3f(0.11, 0.11, 0.11);
    glBegin(GL_POLYGON);
    glVertex2f(-0.86f,0.125f) ;
    glVertex2f(-0.86f,0.2f);
    glVertex2f(-0.8f,0.2f);
    glVertex2f(-0.8f,0.125f);
    glEnd();


}


void vsillouhette()
{
    glColor4f(0.24, 0.47, 0.59,0.4);


    glBegin(GL_QUADS);
    glVertex2f(-0.0f,0.5f) ;
    glVertex2f(-0.2f,0.5f);
    glVertex2f(-0.2f,-.125f);
    glVertex2f(-0.0f,-0.125f);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(-0.2f,0.375f);
    glVertex2f(-0.3f,0.375f);
    glVertex2f(-0.3f,-.125f);
    glVertex2f(-0.2f,-0.125f);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(-0.3f,0.425f);
    glVertex2f(-0.4f,0.425f);
    glVertex2f(-0.4f,-.125f);
    glVertex2f(-0.3f,-0.125f);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(-0.4f,0.375f);
    glVertex2f(-0.5f,0.375f);
    glVertex2f(-0.5f,-.125f);
    glVertex2f(-0.4f,-0.125f);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(-0.5f,0.45f);
    glVertex2f(-0.6,0.45f);
    glVertex2f(-0.6f,-.125f);
    glVertex2f(-0.5f,-0.125f);
    glEnd();


    glBegin(GL_QUADS);
    glVertex2f(-0.6f,0.5f);
    glVertex2f(-0.7,0.5f);
    glVertex2f(-0.7f,-.125f);
    glVertex2f(-0.6f,-0.125f);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(-0.7f,0.35f);
    glVertex2f(-0.8,0.35f);
    glVertex2f(-0.8f,-.125f);
    glVertex2f(-0.7f,-0.125f);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(-0.8f,0.475f);
    glVertex2f(-0.9,0.475f);
    glVertex2f(-0.9f,-.125f);
    glVertex2f(-0.8f,-0.125f);
    glEnd();

    glBegin(GL_QUADS);
    glVertex2f(-0.9f,0.375f);
    glVertex2f(-1,0.375f);
    glVertex2f(-1,-.125f);
    glVertex2f(-0.9f,-0.125f);
    glEnd();



}



void road()
{
    glColor3f(0.08, 0.08, 0.08);
    glBegin(GL_POLYGON);
    glVertex2f(-1,-0.25f) ;
    glVertex2f(1,-0.25f);
    glVertex2f(1,-0.525f);
    glVertex2f(-1,-0.525f);
    glEnd();



    //LINES OF ROADS
    float x2=-0.94;
    glColor3f(0.82, 0.82, 0.82);

    while(x2<=1)
    {
    glBegin(GL_POLYGON);
    glVertex2f(x2,-0.375f) ;
    glVertex2f(x2+0.14,-0.375f);
    glVertex2f(x2+0.14,-0.35f);
    glVertex2f(x2,-0.35f);
    glEnd();

    x2+=0.28;
    }





}

void roaddetails()
{

    glColor3f(0.86, 0.8, 0.01);
    glBegin(GL_POLYGON);
    glVertex2f(-1,-0.525f) ;
    glVertex2f(1,-0.525f);
    glVertex2f(1,-0.6f);
    glVertex2f(-1,-0.6f);
    glEnd();

     //BLOCK RIVER
    glLineWidth(5.0); // Change this value to set the desired line widt
    float x1=-1;
    glColor3f(0.14, 0.14, 0.12);
    glBegin(GL_LINES);
    while(x1<=1)
    {
    glVertex2f(x1,-0.525f) ;
    glVertex2f(x1+0.025,-0.6f);
    x1+=0.05;
    }
    glEnd();


    glColor3f(0.52, 0.23, 0.02);
    glLineWidth(5.0); // Change this value to set the desired line widt
    glBegin(GL_LINES);
    glVertex2f(-1,-0.45f) ;
    glVertex2f(1,-0.45f);
    glEnd();

    float x3=-1;
    glBegin(GL_LINES);
    while(x3<=1)
    {
    glVertex2f(x3,-0.525f) ;
    glVertex2f(x3,-0.45f);
    x3+=0.08;
    }
    glEnd();
    glLineWidth(1.0); // Change this value to set the desired line widt



}






void vground()
{
    glColor3f(0, 0.46, 0.01);
    glBegin(GL_POLYGON);
    glVertex2f(-1,-0.25f) ;
    glVertex2f(0,-0.25f);
    glVertex2f(0,0);
    glVertex2f(-1,0);
    glEnd();
}




void cng()
{

    glPushMatrix(); // Push the current matrix onto the matrix stack
    glTranslatef(cngPositionX, 0.0, 0.0); // Translate the CNG based on its position

    //WHEELS
    glColor3f(0.13, 0.13, 0.13);
    drawCircle(-0.60876,-0.46174,0.0312);
    drawCircle(-0.30508,-0.46369,0.0312);


    glColor3f(0, 0.27, 0.04);
    glBegin(GL_POLYGON);
    // Define vertices of the polygon
    glVertex2f(-0.61719, -0.428);   // H
    glVertex2f(-0.63844, -0.43241); // G
    glVertex2f(-0.62513, -0.41074); // M
    glVertex2f(-0.59537, -0.39769); // L
    glVertex2f(-0.58914,-0.40868); // K
    glVertex2f(-0.56398, -0.44552); // J
    glVertex2f(-0.59124, -0.44357); // I
    glEnd();

    glBegin(GL_POLYGON);
// Define vertices of the polygon
    glVertex2f(-0.28605, -0.42587); // R
    glVertex2f(-0.26693, -0.43446); // S
    glVertex2f(-0.24937, -0.43407); // T
    glVertex2f(-0.26966, -0.26667); // U
    glVertex2f(-0.28175, -0.24716); // V
    glVertex2f(-0.30361, -0.23311); // W
    glVertex2f(-0.53929, -0.23506); // Z
    glVertex2f(-0.60445, -0.33691); // A1
    glVertex2f(-0.59977, -0.38919); // B1
    glVertex2f(-0.58182, -0.43094); // C1
    glVertex2f(-0.55373, -0.45084); // N
    glVertex2f(-0.34614, -0.45358); // O
    glVertex2f(-0.32507, -0.42587); // P
    glVertex2f(-0.26771, -0.44772); // Q
    glEnd();


    // Draw the triangle
    glBegin(GL_TRIANGLES);
    // Set slight blue color for glass
    glColor3f(0.3, 0.5, 0.8);
    glVertex2f(-0.53929, -0.23506);
    glVertex2f(-0.60445, -0.33691);
    glVertex2f(-0.54918, -0.33757);
    glEnd();

    glColor3f(0.12, 0.13, 0.12);
    glBegin(GL_POLYGON);
    // Define vertices of the polygon
    glVertex2f(-0.47216, -0.3947); // I1
    glVertex2f(-0.4546, -0.39331);  // H1
    glVertex2f(-0.45506, -0.24816); // G1
    glVertex2f(-0.53041, -0.24955); // F1
    glVertex2f(-0.54277, -0.26198); // A1
    glVertex2f(-0.54918, -0.33757); // D1
    glVertex2f(-0.54289, -0.44879); // K1
    glVertex2f(-0.47292, -0.44857); // E1
    glEnd();

    glBegin(GL_POLYGON);
    // Define vertices of the polygon
    glVertex2f(-0.35743, -0.34918); // J1
    glVertex2f(-0.3608, -0.26836);  // L1
    glVertex2f(-0.37831, -0.2522);  // M1
    glVertex2f(-0.45506, -0.24816); // G1
    glVertex2f(-0.54061, -0.24546); // N1
    glVertex2f(-0.54075, -0.23625); // O1
    glVertex2f(-0.34531, -0.22863); // P1
    glVertex2f(-0.30361, -0.23311); // Z
    glVertex2f(-0.28175, -0.24716); // W
    glVertex2f(-0.26966, -0.26667); // V
    glVertex2f(-0.26045, -0.34244); // Q1
    glEnd();


    glPopMatrix(); // Restore the previous matrix from the stack
}

void car1() {
    // Base
    glColor3f(0.71, 0.01, 0.07);
    glBegin(GL_POLYGON);
    glVertex2f(carPosX, 0.125);
    glVertex2f(carPosX, 0.2);
    glVertex2f(carPosX + 0.14, 0.2);
    glVertex2f(carPosX + 0.2, 0.175);
    glVertex2f(carPosX + 0.2, 0.125);
    glVertex2f(carPosX, 0.125);
    glEnd();

    // Windows
    glColor3f(0.44, 0.75, 0.93);
    glBegin(GL_POLYGON);
    glVertex2f(carPosX + 0.02, 0.2);
    glVertex2f(carPosX + 0.04, 0.25);
    glVertex2f(carPosX + 0.12, 0.25);
    glVertex2f(carPosX + 0.14, 0.2);
    glVertex2f(carPosX + 0.02, 0.2);
    glEnd();

    // Window border
    glLineWidth(2.0f);
    glColor3f(0.71, 0.01, 0.07);
    glBegin(GL_LINES);
    glVertex2f(carPosX + 0.08, 0.2);
    glVertex2f(carPosX + 0.08, 0.25);
    glEnd();

    // Wheels
    glColor3f(0, 0, 0);
    drawCircle(carPosX + 0.04, 0.125, 0.02);
    drawCircle(carPosX+.14, 0.125, 0.02);
}












void village()
{
    tree(-.265,-.15,.7,0.16, 0.61, 0.03);
     tree(-.6,-.125,.6,0.18, 0.81, 0);
     tree(-.54,-.13,.8,0.11, 0.51, 0);
     tree(-.95,-.13,.7,0.11, 0.51, 0);
     tree(-.92,-.15,.5,0.1, 0.34, 0.04);
    vhouse1();

    vhouse2();
    vhouse3();
    bush(-.98,-.21);
    tree(-.26,-.2375,.5,0.09, 0.33, 0.02);
    tree(-.59,-.2475,.6,0.15, 0.46, 0.06);
    tree(-.95,-.2475,.3,0.05, 0.13, 0.03);

    bush(-.24,-0.225);
    bush(-.6,-.245);
    bush(-.87,-.2);
}



void city()
{
    //shde1
    glColor3f(0.57, 0.72, 0.84);
    glBegin(GL_POLYGON);
    glVertex2f(0.57, .2);
    glVertex2f(.63,.2);
    glVertex2f(.63, .7);
      glVertex2f(.57, .75);
    glVertex2f(0.57, .75);
    glEnd();


    glColor3f(0.57, 0.72, 0.84);
    glBegin(GL_POLYGON);
    glVertex2f(0.9, .2);
    glVertex2f(1.,.2);
    glVertex2f(1., .7);
    glVertex2f(0.9, .7);
    glEnd();
//shade2

glColor3f(0.28, 0.54, 0.7);
    glBegin(GL_POLYGON);
    glVertex2f(0.6,0.25);
    glVertex2f(.7,0.25);
    glVertex2f(.7, .5);
    glVertex2f(.6, .5);
    glEnd();

    glBegin(GL_POLYGON);
    glVertex2f(0.,0);
    glVertex2f(1,0);
    glVertex2f(1, .25);
    glVertex2f(0, .25);
    glEnd();


     glColor3f(0.28, 0.54, 0.7);
    glBegin(GL_POLYGON);
    glVertex2f(0.78, .25);
    glVertex2f(.87,.25);
    glVertex2f(.87, .6);
    glVertex2f(0.78, .6);
    glEnd();


    glColor3f(0.28, 0.54, 0.7);
    glBegin(GL_POLYGON);
    glVertex2f(0.78, .6);
    glVertex2f(.87,.6);
    glVertex2f(.825, .65);
    //glVertex2f(0.78, .6);
    glEnd();

    //shade2

    glColor3f(0.28, 0.54, 0.7);
    glBegin(GL_POLYGON);
    glVertex2f(0.45, .15);
    glVertex2f(.55,.15);
    glVertex2f(.55, .4);
    glVertex2f(0.45, .4);
    glEnd();

    glColor3f(0.28, 0.54, 0.7);
    glBegin(GL_POLYGON);
    glVertex2f(0.48, .15);
    glVertex2f(.52,.15);
    glVertex2f(.52, .5);
    glVertex2f(0.48, .5);
    glEnd();

    glColor3f(0.28, 0.54, 0.7);
    glBegin(GL_POLYGON);
    glVertex2f(0.49, .15);
    glVertex2f(.51,.15);
    glVertex2f(.51, .5);
    glVertex2f(0.49, .5);
    glEnd();

    //shade

    glColor3f(0.28, 0.54, 0.7);
    glBegin(GL_POLYGON);
    glVertex2f(0.2, -.1);
    glVertex2f(.3,-.1);
    glVertex2f(.3, .60);
    glVertex2f(0.2, .55);
     glVertex2f(0.2, .15);
    glEnd();



//last building
    glColor3f(0.68, 0.38, 0.85);
    glBegin(GL_POLYGON);
    glVertex2f(0.7, -.1);
    glVertex2f(1.0,-.1);
    glVertex2f(1.0, .3);
    glVertex2f(0.7, .3);
    glEnd();

    glColor3f(0.76, 0.76, 0.75);
    glBegin(GL_POLYGON);
    glVertex2f(0.73, 0.0);
    glVertex2f(0.97,0.0);
    glVertex2f(0.97, .28);
    glVertex2f(0.73, .28);
    glEnd();

    glColor3f(0.62, 0.38, 0.85);
    glLineWidth(10.0);
    glBegin(GL_LINES);//line
    glVertex2f(0.7,0.07);
    glVertex2f(1.,0.07);
    glEnd();

    glColor3f(0.62, 0.38, 0.85);
    glLineWidth(10.0);
    glBegin(GL_LINES);//line
    glVertex2f(0.7,0.17);
    glVertex2f(1.,0.17);
    glEnd();

    glColor3f(0.62, 0.38, 0.85);
    glLineWidth(10.0);
    glBegin(GL_LINES);//line
    glVertex2f(0.7,0.27);
    glVertex2f(1.,0.27);
    glEnd();

    glColor3f(0.62, 0.38, 0.85);
    glLineWidth(11.0);
    glBegin(GL_LINES);//line
    glVertex2f(0.810,0.3);
    glVertex2f(0.81,0.00);
    glEnd();

    glColor3f(0.62, 0.38, 0.85);
    glLineWidth(11.0);
    glBegin(GL_LINES);//line
    glVertex2f(0.9,0.3);
    glVertex2f(0.9,0.00);
    glEnd();

    glColor3f(0.35, 0.35, 0.33);
    glBegin(GL_POLYGON);
    glVertex2f(0.82, -0.10);
    glVertex2f(0.885,-0.10);
    glVertex2f(0.885, .055);
    glVertex2f(0.82, .055);
    glEnd();

     glColor3f(0.29, 0.1, 0.46);
    glBegin(GL_POLYGON);
    glVertex2f(0.68, .27);
    glVertex2f(0.7,0.30);
    glVertex2f(1., .3);
    glVertex2f(1., .27);
    glEnd();

    //yellow

    glColor3f(0.92, 0.91, 0.18);
    glBegin(GL_POLYGON);
    glVertex2f(0.5, -.1);
    glVertex2f(.7,-.1);
    glVertex2f(.70, .2);
    glVertex2f(0.5, .2);
    glEnd();

    glColor3f(0.6, 0.44, 0.28);
    glBegin(GL_POLYGON);
    glVertex2f(0.58, -.1);
    glVertex2f(.62,-.1);
    glVertex2f(.62, .04);
    glVertex2f(0.58, .04);
    glEnd();

    glColor3f(0.8, 0.73, 0.42);
    glBegin(GL_POLYGON);
    glVertex2f(0.5, -.1);
    glVertex2f(.7,-.1);
    glVertex2f(.70, -.07);
    glVertex2f(0.5, -.07);
    glEnd();

    glColor3f(0.19, 0.68, 0.96);
    glBegin(GL_POLYGON);
    glVertex2f(0.52, -.04);
    glVertex2f(.56,-.04);
    glVertex2f(.56, .15);
    glVertex2f(0.52, .15);
    glEnd();

     glColor3f(0.19, 0.68, 0.96);
    glBegin(GL_POLYGON);
    glVertex2f(0.64, -.04);
    glVertex2f(.68,-.04);
    glVertex2f(.68, .15);
    glVertex2f(0.64, .15);
    glEnd();


    glColor3f(0.92, 0.91, 0.18);
    glBegin(GL_POLYGON);
    glVertex2f(0.52, .04);
    glVertex2f(.68,.04);
    glVertex2f(.68, .08);
    glVertex2f(0.52, .08);
    glEnd();



    glColor3f(0.5, 0.42, 0.01);
    glBegin(GL_POLYGON);
    glVertex2f(0.5, .2);
    glVertex2f(.7,.2);
    glVertex2f(.68, .23);
    glVertex2f(0.52, .23);
    glEnd();


    glColor3f(0.03, 0.85, 0.12);
    glBegin(GL_POLYGON);
    glVertex2f(0, -0.1);
    glVertex2f(1,-0.1);
    glVertex2f(1, -0.17);
    glVertex2f(0, -0.17);
    glEnd();



    /*1st red building*/

     glColor3f(0.850, 0.0, 0.0);
glLineWidth(1.0);
glBegin(GL_POLYGON);
    glVertex2f(0.0,-0.10);
    glVertex2f(0.25, -0.10);
    glVertex2f(0.25, 0.30);
    glVertex2f(0.0, 0.30);
     glEnd();

/*ceiling*/
     glColor3f(0.650, 0.0, 0.0);
glLineWidth(1.0);
glBegin(GL_POLYGON);
    glVertex2f(0.0,0.27);
    glVertex2f(0.26, 0.27);
    glVertex2f(0.26, 0.30);
    glVertex2f(0.0, 0.30);
     glEnd();
/*floor*/
 glColor3f(0.83, 0.47, 0.47);
glLineWidth(1.0);
glBegin(GL_POLYGON);
    glVertex2f(0.0,-0.10);
    glVertex2f(0.25, -0.10);
    glVertex2f(0.25, -0.030);
    glVertex2f(0.0, -0.030);
     glEnd();
/*door*/
glColor3f(0.550, 0.0, 0.0);

glLineWidth(1.0);
glBegin(GL_POLYGON);
    glVertex2f(0.09,-0.030);
    glVertex2f(0.16, -0.030);
    glVertex2f(0.16, 0.070);
    glVertex2f(0.09, 0.070);
     glEnd();




   glColor3f(0.06, 0.05, 0.05);

glLineWidth(1.0);
glBegin(GL_POLYGON);
    glVertex2f(0.13,0.0);
    glVertex2f(0.14, 0.0);
    glVertex2f(0.14, 0.02);
    glVertex2f(0.13, 0.02);
     glEnd();





glColor3f(0.06, 0.05, 0.05);
glLineWidth(1.0);
glBegin(GL_POLYGON);
    glVertex2f(0.085,-0.030);
    glVertex2f(0.09, -0.030);
    glVertex2f(0.09, 0.070);
    glVertex2f(0.085, 0.070);
     glEnd();


glColor3f(0.06, 0.05, 0.05);
glLineWidth(1.0);
glBegin(GL_POLYGON);
     glVertex2f(0.16,-0.030);
    glVertex2f(0.165, -0.030);
    glVertex2f(0.165, 0.070);
    glVertex2f(0.16, 0.070);
     glEnd();

glColor3f(0.06, 0.05, 0.05);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.07,0.070);
    glVertex2f(0.18, 0.070);
    glVertex2f(0.18, 0.080);
    glVertex2f(0.07, 0.080);
     glEnd();
/*stairs*/
   glColor3f(0.48, .22, 0.22);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.07,-0.10);
    glVertex2f(0.18,-0.10);
    glVertex2f(0.18, -0.080);
    glVertex2f(0.07, -0.080);
     glEnd();


   glColor3f(0.48, 0.22, 0.22);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.08,-0.070);
    glVertex2f(0.17,-0.070);
    glVertex2f(0.17, -0.055);
    glVertex2f(0.08, -0.055);
     glEnd();

     glColor3f(0.48, 0.22, 0.22);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.09,-0.046);
    glVertex2f(0.16,-0.046);
    glVertex2f(0.16, -0.030);
    glVertex2f(0.09, -0.030);
     glEnd();




/*windows*/
glColor3f(0.93, 1.88, 1.88);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.02,0.10);
    glVertex2f(0.23,0.10);
    glVertex2f(0.23, 0.25);
    glVertex2f(0.02, 0.25);
     glEnd();


glColor3f(0.850, .0, 0.0);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.07,0.10);
    glVertex2f(0.10,0.10);
    glVertex2f(0.10, 0.25);
    glVertex2f(0.07, 0.25);
     glEnd();


glColor3f(0.850, .0, 0.0);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.15,0.10);
    glVertex2f(0.18,0.10);
    glVertex2f(0.18, 0.25);
    glVertex2f(0.15, 0.25);
     glEnd();


glColor3f(0.850, 0.0, 0.0);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.02,0.15);
    glVertex2f(0.23,0.15);
    glVertex2f(0.23, 0.20);
    glVertex2f(0.02, 0.20);
     glEnd();

glColor3f(0.93, 0.88, 0.88);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.02,0.01);
    glVertex2f(0.07,0.01);
    glVertex2f(0.07, 0.06);
    glVertex2f(0.02, 0.06);
     glEnd();

glColor3f(0.93, 0.88, 0.88);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.18,0.01);
    glVertex2f(0.23,0.01);
    glVertex2f(0.23, 0.06);
    glVertex2f(0.18, 0.06);
     glEnd();


   /*2nd Building*/

     glColor3f(0.72, 0.55, 0.9);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.26,-0.10);
    glVertex2f(0.55,-0.10);
    glVertex2f(0.55, 0.40);
    glVertex2f(0.26, 0.40);
     glEnd();

/*ceiling*/

glColor3f(0.61, 0.43, 0.81);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.24,0.40);
    glVertex2f(0.57,0.40);
    glVertex2f(0.55, 0.45);
    glVertex2f(0.26, 0.45);
     glEnd();

/*window*/


glColor3f(0.97, 0.95, 1);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.28,0.19);
    glVertex2f(0.53,0.19);
    glVertex2f(0.53, 0.35);
    glVertex2f(0.28, 0.35);



     glVertex2f(0.28,-0.05);
    glVertex2f(0.40,-0.05);
    glVertex2f(0.40, 0.35);
    glVertex2f(0.28, 0.35);

     glEnd();


    glColor3f(0.72, 0.55, 0.9);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.33,-0.06);
    glVertex2f(0.35,-0.06);
    glVertex2f(0.35, 0.35);
    glVertex2f(0.33, 0.35);

       glEnd();




    glColor3f(0.72, 0.55, 0.9);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.40,0.19);
    glVertex2f(0.42,0.19);
    glVertex2f(0.42, 0.35);
    glVertex2f(0.40, 0.35);

       glEnd();


    glColor3f(0.72, 0.55, 0.9);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.47,0.19);
    glVertex2f(0.49,0.19);
    glVertex2f(0.49, 0.35);
    glVertex2f(0.47, 0.35);

       glEnd();


 glColor3f(0.72, 0.55, 0.9);
glLineWidth(1.0);
glBegin(GL_POLYGON);
 glVertex2f(0.28,0.10);
    glVertex2f(0.40,0.10);
    glVertex2f(0.40, 0.19);
    glVertex2f(0.28, 0.19);

       glEnd();




/*door*/

      glColor3f(0.97, 0.95, 1);
glLineWidth(1.0);
glBegin(GL_POLYGON);
glVertex2f(0.42,-0.10);
    glVertex2f(0.53,-0.10);
    glVertex2f(0.53, 0.12);
    glVertex2f(0.42, 0.12);


    glVertex2f(0.53,0.12);
    glVertex2f(0.47, 0.18);
    glVertex2f(0.42, 0.12);

     glEnd();


 glColor3f(0.38, 0.26, 0.57);
glLineWidth(1.0);
glBegin(GL_POLYGON);
glVertex2f(0.44,-0.05);
    glVertex2f(0.51,-0.05);
    glVertex2f(0.51, 0.08);
    glVertex2f(0.44, 0.08);
  glEnd();


 glColor3f(0.97, 0.95, 1);
glLineWidth(1.0);
glBegin(GL_POLYGON);
glVertex2f(0.47,-0.05);
    glVertex2f(0.48,-0.05);
    glVertex2f(0.48, 0.08);
    glVertex2f(0.47, 0.08);
   glEnd();


 glColor3f(0.97, 0.95, 1);
glLineWidth(1.0);
glBegin(GL_POLYGON);
glVertex2f(0.44,0.01);
    glVertex2f(0.51,0.01);
    glVertex2f(0.51, 0.03);
    glVertex2f(0.44, 0.03);
  glEnd();

/*floor*/

    glColor3f(0.41, 0.3, 0.58);
    glLineWidth(1.0);
    glBegin(GL_POLYGON);
    glVertex2f(0.26,-0.10);
    glVertex2f(0.55,-0.10);
    glVertex2f(0.55,- 0.08);
    glVertex2f(0.26, -0.08);
    glEnd();
}







//ANIMATIONS
void updatesun(int value)
{
    updateSunPosition();
    glutPostRedisplay(); // Request a redraw
    glutTimerFunc(16, updatesun, 0); // Schedule the next update
}

void updateriver(int value) {
    // Update the offset to shift the lines
    xOffset += 0.001;

    // Wrap around the offset to create an endless loop
    if (xOffset > 0.2)
        xOffset = 0.0;

    glutPostRedisplay(); // Trigger a redraw
    glutTimerFunc(16, updateriver, 0); // Call update function after 16 milliseconds (for ~60 FPS)
}




void updatecng(int value) {
    if (moveCNG) {
        // Update the position of the CNG
        cngPositionX -= 0.01; // Adjust the speed as needed
        if (cngPositionX < -1.5) {
            cngPositionX = 2; // Reset the position when it goes off the screen
        }
    }

    glutPostRedisplay(); // Mark the current window as needing to be redisplayed
    glutTimerFunc(16, updatecng, 0); // Call update function again after 16 milliseconds
}
void updatecar1(int value) {

    // Check if the car has reached the right edge of the screen
    if (moveCar) {
        // Update the car's position
        carPosX += 0.01;
        // Check if the car has reached the right edge of the screen
        if (carPosX > 2.6) {
            carPosX = -1.8; // Reset car position to the left side of the screen
        }
    }


    glutPostRedisplay(); // Request a redraw
    glutTimerFunc(16, updatecar1, 0); // Call update function after 16 milliseconds

}

void keyboard(unsigned char key, int x, int y) {
    switch (key)
    {
    case 'd':
    case 'D':
        moveCNG = !moveCNG; // Toggle the movement flag
        break;
    case 'a':
    case 'A':
        moveCar = !moveCar; // Toggle the movement flag when 'A' key is pressed
        break;

    }
}

// Function to initialize OpenGL

void init() {
    // Set the clear color to white
    glClearColor(1.0, 1.0, 1.0, 1.0);
    // Set the coordinate system
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1.0, 1.0, -1.0, 1.0);
}

// Function to display content
void display() {
    // Clear the color buffer
    glClear(GL_COLOR_BUFFER_BIT);


    createSky();
    drawGlowingSun(sunX, sunY, sunRadius, numSegments);
    river();
    riverlines();
    vground();
    vsillouhette();
    village();
    city();
    centerdivider();

    road();





    shiftX = 0;
    shiftY = 0.02;

    scaleX = -.7;
    scaleY = .7;

    glPushMatrix();
    glScalef(scaleX, scaleY, 1.0f);
    glTranslatef(shiftX, shiftY, 0.0f);
    cng();
    glPopMatrix();


    shiftX = 0;
    shiftY = -.45;

    scaleX = -1.4;
    scaleY = 1.4;

    glPushMatrix();
    glScalef(scaleX, scaleY, 1.0f);
    glTranslatef(shiftX, shiftY, 0.0f);
    car1();
    glPopMatrix();


    roaddetails();

    // Swap the buffers to display the content
    glutSwapBuffers();
}











int main(int argc, char** argv) {
    // Initialize GLUT
    glutInit(&argc, argv);
    // Set display mode
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    // Set window size and position
    glutInitWindowSize(1600, 1200);
    glutInitWindowPosition(100, 100);


    // Create a window with the specified title
    glutCreateWindow("SCENE 2");
    glutTimerFunc(0, updatesun, 0); // Start the update loop
    glutTimerFunc(0, updateriver, 0); // Start the update loop
    glutTimerFunc(16, updatecng, 0); // Call update function again after 16 milliseconds
    glutTimerFunc(16, updatecar1, 0);

    // Initialize OpenGL
    init();
    // Register display callback function
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard); // Register keyboard callback function
    // Enter the GLUT event processing loop
    glutMainLoop();
    return 0;
}
